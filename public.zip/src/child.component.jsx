import React, { Component } from "react";
 
class ChildComp extends Component{
    ipRef = React.createRef();
    state = {
        version : 0
    };
    constructor(){
        super();
       // this.state.version = 5;
        console.log("ChildComp's constructor was called");
    }
   
    render(){
        console.log("ChildComp's render was called");
        return <div style={ { border : "2px solid red", padding :"10px", margin : "10px" }}>
                <h2> Applicant's Name : </h2>
                <h2> Technology Area: dropdown(mandatory) :  </h2>
                <h2> Skill :  </h2>
                <h3> HTML  </h3>
                <h4> JavaScript </h4>
               
               </div>
        }
    }
    
    
    export default ChildComp;