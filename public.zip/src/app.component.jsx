import React, { Component } from "react";
import ChildComp from "./child.component";


class AppComp extends Component{

    state = {
        power : 0,
        show : true
    }
   
   
    render(){
        return <div style={{}}>
            
               

              <h2 style={ { border : "2px solid red", padding :"10px", margin : "10px" }}>
              <img src=".src/image/ibm2.jpg" alt="" width="150px" height="100px"/>
              <center>
              <button ><center>Template</center></button>
              <button><center>Evaluation</center></button>
              <button><center>contact us</center></button> </center>
              </h2>
              
                <br />
                <br />
                { this.state.show && <ChildComp pow={ this.state.power }/>}
                </div>
        }
}
export { AppComp };