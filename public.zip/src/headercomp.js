import { Component } from "react";
import img1 from "./img1";
import TimeplateComp from "./Template.component";

class HeaderComp extends Component{
    render(){
        return  <nav className="navbar navbar-expand-1g navbar-light bg-light">
                 <div className="container-fluid p-3 mb-2 bg-info text-white">
                     <img src={img1} alt="" className="d-inling-block align-text-top"/>
                     <TimeplateComp/>
                 </div>
        </nav>
    }
}

export default HeaderComp;