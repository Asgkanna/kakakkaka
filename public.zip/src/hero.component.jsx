import { Component } from "react";

class HeroComp extends Component{
    render(){
        return <div>
                   <h2>Title : { this.props.title }</h2>
                   
                   <ol>{
                       this.props.heroeslist.map( (val, idx, arr)=> <li key={idx}>{ val }</li> ) 
                       }</ol>
               </div>
    }
}

export { HeroComp };